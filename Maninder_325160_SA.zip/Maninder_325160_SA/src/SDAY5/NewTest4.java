package SDAY5;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class NewTest4 {
	@BeforeClass
	 public void bc() {
		System.out.println("i came to the cricket stadium");
	  }
	@AfterClass
	public void ac() {
		System.out.println("now i am home back");
	  }
	@BeforeMethod
	public void bm() {
		System.out.println("hello");
	}
	@AfterMethod
	public void am() {
		System.out.println("bye");
	}
	
	
  @Test
  public void t1() {
	  System.out.println("i met mr.dhoni");
  }
  
	
  @Test
  public void t2() {
	  System.out.println("i met mr.dhoni");
  }
	
  @Test
  public void t3() {
	  System.out.println("i took a pic with mr.rohit sharma");
  }
}
