package SDAY5;

import java.util.ArrayList;

import SDAY4.loginexcel;

public class datamain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		dataexcel lx=new dataexcel();
		data lg=new data();
		ArrayList<data> al=new ArrayList<data>();
		ArrayList<data> al1;
		int c=0;
//		ArrayList<data> al2;
//		data d;

		al1=lx.read(al);
		System.out.println(al1.get(0));
		

		for(data ld:al1) {
			data d=lx.Login(ld);
			al1.set(c,d);
			c++;
		}
		lx.write(al1);


}}
