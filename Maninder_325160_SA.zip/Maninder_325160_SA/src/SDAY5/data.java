package SDAY5;

public class data {
	public String uid;
	public String pass;
	public String exr;
	public String exem1;
public String exerm2;
public String acr;
public String acem1;
public 	String acem2;
public 	String trslt;

}
