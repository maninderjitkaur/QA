package SDAY5;

import org.testng.annotations.Test;

public class NewTest3 {
	login lg,lg1;
	loginexcel lx;
  @Test
  public void t1() {
	  login lg=new login();
	  login lg1=new login();
	  loginexcel lx=new loginexcel();
	  lg.uid="nudrufadra@enayu.com";
	  lg.pass="Sel1234";
	  lg.exr="SUCCESS";
	  lg1=lx.Login(lg);
	  System.out.println(lg1.acr);
	  
	  
  }
}
