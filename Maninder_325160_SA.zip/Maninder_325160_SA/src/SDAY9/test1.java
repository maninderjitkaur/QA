package SDAY9;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;

public class test1 {
	
	login_page lp;
	home_page hp;
	WebDriver dr;
	cart_page cp;
	
	
	
  @Test
  public void t1() {
	 
	  lp.do_login("standard_user", "secret_sauce");
	  String exp = dr.findElement(By.xpath("//*[@id=\"item_4_title_link\"]/div")).getText();
	  hp.add_to_cart(1);
	  hp.click_cart();
	  
	 String a_pn = cp.verify();
	  SoftAssert sa = new SoftAssert();
	  sa.assertEquals(exp,a_pn);
	  sa.assertAll();
	  
	  
	  
  }
  @BeforeClass
  public void bc() {
	  
	  System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
		dr = new ChromeDriver();
		dr.get("https://www.saucedemo.com/");
		lp = new login_page(dr);
		hp = new home_page(dr);
		cp = new cart_page(dr);
	  
  }

}

