package SDAY9;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class cart_page {
	WebDriver dr;
	
	
	public cart_page(WebDriver dr) {
		this.dr=dr;
		PageFactory.initElements(dr, this);
	}
	
	
	public String verify() {
		
		 String a_pn = dr.findElement(By.xpath("//*[@id=\"item_4_title_link\"]/div")).getText();
		 return a_pn;
	}

}
