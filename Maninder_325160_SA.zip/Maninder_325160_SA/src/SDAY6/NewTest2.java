package SDAY6;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class NewTest2 {
  @Test
  public void t1() {
	  String s="noida",s1="noida";
	  Assert.assertEquals(s, s1);
	  System.out.println("in 1st function");
  }
  @Test
  public void t2() {
	  String s="noida",s1="ghgftgdutdt";
	  SoftAssert sa1=new SoftAssert();
	  
	  sa1.assertEquals(s, s1);
	  System.out.println("in 2nd function");
	  sa1.assertAll();
  }
  @Test
  public void t3() {
	  String s="noida",s1="noida1";
	  Assert.assertEquals(s, s1);
	  System.out.println("in 3rd function");
  }
}
