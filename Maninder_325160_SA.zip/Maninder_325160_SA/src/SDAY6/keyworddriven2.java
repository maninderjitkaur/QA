package SDAY6;

import org.openqa.selenium.WebDriver;

public class keyworddriven2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String kw,xp,td,z,y,x;
		WebDriver dr = null;
		all_webelement_fnc we = new all_webelement_fnc(dr);
		excel_operation excel = new excel_operation ();
//		xcel_data xd = new xcel_data();
		
		//code for register
		for(int r=1;r<=15;r++) {
			kw = excel.read_excel(r,3);
			xp = excel.read_excel(r,4);
			td = excel.read_excel(r,5);
		
				
		switch(kw)
		{
		case "launchchrome":
			System.out.println("Launching chrome");
			we.launchChrome(td);
			break;
			
		case "enter_txt":
			we.enter_txt(xp,td);
			break;
			
		case "click_btn":
			we.click(xp);
			break;
			
		case "click_rb" :
			we.click_rbtn();
			break;
			
		case "verify" :
			we.verify(td);
			break;
			
		case "closebrowser" :
			we.closebrow();
			break;
			
		//default: System.out.println("error");
			
		}
		}
//		for(int i=0;i<2;i++) {
//			excel.write_excel(str);
//		}
		
		//code for login
		/*for(int r=11;r<=14;r++) {
			z = excel.read_excel(r,3);
			y = excel.read_excel(r,4);
			x = excel.read_excel(r,5);
		
				
		switch(z)
		{
		case "launchchrome":
			System.out.println("Launching chrome");
			we.launchChrome(x);
			break;
			
		case "enter_txt":
			we.enter_txt(y,x);
			break;
			
		case "click_btn":
			we.click_btn(y);
			break;
			
		//default: System.out.println("error");
			
		}
		}*/

	}

	}


