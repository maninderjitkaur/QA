package SDAY6;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import SDAY5.data;

public class excel_operation {

	public String read_excel(int n, int i) {
		// TODO Auto-generated method stub
		String s = null;
			try {
				
				File f=new File("C:\\training\\keydriven2.xlsx");
				FileInputStream fis=new FileInputStream(f);
				XSSFWorkbook wb= new XSSFWorkbook(fis);
				XSSFSheet sh=wb.getSheet("Sheet1");
				XSSFRow r=sh.getRow(n);
				XSSFCell c=r.getCell(i);
				s=(String)c.getStringCellValue();
//				System.out.println(ld.uid);
				
				
				}
				
	
	catch(Exception e) {
		System.out.println(e);
	}
		return s;
	}
	
	static login ld;
	//static ArrayList<login_data> arl;
	int row=9;
	
	
	
	public static login login () {
		//login_data ld = new login_data();
		System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
		WebDriver dr = new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/login");
		//login auto
		dr.findElement(By.id("Email")).sendKeys(ld.uid);
		dr.findElement(By.id("Password")).sendKeys(ld.pass);
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
		
		
		
		//verifying still in same login page
		boolean f = dr.getTitle().contains("Login");
		if(!f)
		{
			ld.acr = "SUCCESS";
			System.out.println("Login Success");
			if(ld.exr.equals(ld.acr))
				ld.trslt = "PASS";
			else
				ld.trslt = "FAIL";
		}
		else
		{
			ld.acr = "FAILURE";
			//catch error msg
			ld.acem1 = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/span")).getText();
			ld.acem2 = dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/ul/li")).getText();
			
		}
		if(ld.exr.equals(ld.acr) ) {
		if(ld.exr.equals("FAILURE"))
		{
			System.out.println("Exp em1 :" + ld.exem1 + "\nAct em1 :" + ld.acem1 + "\nExp em2 :" + ld.exerm2 + "\nAct em2 :" + ld.acem2);
			
			if( ld.exem1.equals(ld.acem1) && ld.exerm2.equals(ld.acem2))
			{
				ld.trslt="PASS";
			}
			else
				ld.trslt="FAIL";
		}
		}
		return ld;
		
	}
	
public void write_excel(String str) {
		
		try {
			
			File f = new File("C:\\Training\\kydreglogin.xlsx");
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sh = wb.getSheet("Sheet1");
			
			XSSFRow r = sh.getRow(row);
			XSSFCell c = r.createCell(6);
			c.setCellValue(str);
				
				
				FileOutputStream fos = new FileOutputStream(f);
				wb.write(fos);
				
				
			row = 15;
			
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		}
	
	
	

}
