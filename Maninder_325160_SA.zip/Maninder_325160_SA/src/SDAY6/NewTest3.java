package SDAY6;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import SDAY6.login;
import SDAY5.loginexcel;

public class NewTest3 {
	login lg=new login();
	  login lg1=new login();
	  login lg2=new login();
	  login lg3=new login();
	  loginexcel6 lx=new loginexcel6();
  @Test
  public void f() {
	  
	  lg.uid="nudrufadra@enayu.com";
	  lg.pass="Sel1234";
	  lg.exr="SUCCESS";
	  lg1=lx.Login(lg);

	  
  }
  @Test
  public void f1() {
	  lg.uid="nudrufadra@enayu.com";
	  lg.pass="Sel123554";
	  lg.exr="SUCCESS";
	  lg.exem1="Login was unsuccessful. Please correct the errors and try again.";
	  lg.exerm2="The credentials provided are incorrect";

	  lg1=lx.Login(lg);
	  SoftAssert sa=new SoftAssert();
	  sa.assertEquals(lg1.acr, lg1.exr);

	  sa.assertAll();
  }
  
}
