package SDAY6;

import org.openqa.selenium.WebDriver;

public class keyworddrivenframe {
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String kw,loc,td;
		WebDriver dr=null;
		all_webelement_fnc we=new all_webelement_fnc(dr);
		excel_operation excel=new excel_operation();
		for(int r=1;r<=4;r++) {
			kw=excel.read_excel(r,1);
			loc=excel.read_excel(r,2);
			td=excel.read_excel(r,3);
		
		switch(kw){
			case "launchbrowser" :
				we.launchChrome(td);
				break;
			case "enter_txt" :
				we.enter_txt(loc,td);
				break;
			case "click_btn" :
				we.click(loc);
				break;
			
		}}
	}

}
