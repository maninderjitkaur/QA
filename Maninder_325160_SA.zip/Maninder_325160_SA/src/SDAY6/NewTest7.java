package SDAY6;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;


import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class NewTest7 {
	String acmail;
	WebDriver dr;
  @Test(dataProvider="regis")
  public void login(String gender,String fname,String lname,String id,String pas,String cpas) {
	  System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
		dr=new ChromeDriver();
		acmail=id;
		dr.get("http://demowebshop.tricentis.com/");
		dr.findElement(By.className("ico-register")).click(); 
		dr.findElement(By.xpath(gender)).click();
		dr.findElement(By.xpath("//*[@id=\"FirstName\"]")).sendKeys(fname);
		dr.findElement(By.xpath("//*[@id=\"LastName\"]")).sendKeys(lname);
		dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys(id);
		dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys(pas);
		dr.findElement(By.xpath("//*[@id=\"ConfirmPassword\"]")).sendKeys(cpas);
		dr.findElement(By.xpath("//*[@id=\"register-button\"]")).click();
		test();
  }
  public void test() {
	// TODO Auto-generated method stub
	  
	String exmail=dr.findElement(By.className("account")).getText();
//	String exmail=
//			dr.
	String se="25552676";
	SoftAssert sa=new SoftAssert();
	sa.assertEquals(se, acmail);
	sa.assertAll();
}
@DataProvider(name="regis")
  public String[][] getdata(){
	  String data[][]= {{"//*[@id=\"gender-female\"]","m","k","togayi6852@resmail24.com","Test123","Test123"}};
	return data;
	  
  }
}
