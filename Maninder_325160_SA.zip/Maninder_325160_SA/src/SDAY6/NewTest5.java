package SDAY6;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class NewTest5 {
	basic_login loginobj;
	login ldata,ldataout;
	@BeforeClass
	public void config() {
		ldata=new login();
		ldataout=new login();
		loginobj=new basic_login();
		
	}
	
  @Test(dataProvider="security")
  public void login_test(String u,String p,String expres) {
	  System.out.println("login:"+u+" "+p);
	  ldata.uid=u;ldata.pass=p;ldata.exr=expres;
	  ldataout=loginobj.Login(ldata);
	  SoftAssert sa=new SoftAssert();
	  sa.assertEquals(ldataout.acr, ldataout.exr);
	  sa.assertAll();
  }
  @DataProvider (name="security")
  public String[][] getdata(){
	  String[][] data= {{"nudrufadra@enayu.com","Sel1234","SUCCESS"},
			  {"nudrufadra@enayu.com","Sel@12333","FAILURE"}};
	  return data;
  }
  }

