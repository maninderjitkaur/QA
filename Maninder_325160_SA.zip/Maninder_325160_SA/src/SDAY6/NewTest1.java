package SDAY6;

import org.testng.annotations.Test;

public class NewTest1 {
  @Test(priority=2)
  public void t1() {
	  System.out.println("1st");
  }
  @Test(priority=1)
  public void t2() {
	  System.out.println("2nd");
  }
}
