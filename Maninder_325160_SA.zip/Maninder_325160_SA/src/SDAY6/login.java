package SDAY6;

public class login {
	String uid;
	String pass;
	String exr;
	String exem1;
	String exerm2;
	String acr;
	String acem1;
	String acem2;
	String trslt;
}
