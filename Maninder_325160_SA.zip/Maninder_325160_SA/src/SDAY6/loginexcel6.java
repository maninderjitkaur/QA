package SDAY6;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class loginexcel6 {
	login lg;
//	ArrayList<login> al;
	

	public login Login(login lgg)
	{
	System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
	WebDriver dr=new ChromeDriver();
	dr.get("http://demowebshop.tricentis.com/");
	dr.findElement(By.className("ico-login")).click();
	
	dr.findElement(By.id("Email")).sendKeys(lgg.uid);
	dr.findElement(By.id("Password")).sendKeys(lgg.pass);
//	dr.findElement(By.className("button-1 login-button")).click();
	dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
//	String s=dr.findElement(By.className("account")).getText();
	
	boolean f=dr.getTitle().contains("Login");
//	System.out.println(f);
	if(!f) {
		lgg.acr="SUCCESS";
		
		System.out.println("login successfull");
		lgg.trslt="PASS";
	}
	else {
		lgg.acr="FAILURE";
//		System.out.println("lg.exem1"+"---"+"lg.exerm2");
		lgg.acem1=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/span")).getText();
		lgg.acem2=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/ul/li")).getText();
		if(lgg.exr.contains("FAILURE")) {
//			System.out.println(lg.exem1);
//			System.out.println(lg.acem1);
//			System.out.println(lg.exerm2);
//			System.out.println(lg.acem2);
			
		if(lgg.exem1.equals(lgg.acem1)&&(lgg.exerm2.equals(lgg.acem2))) {
			lgg.trslt="PASS";
		}}
		
		
		else {
			lgg.trslt="FAIL";
		}
	}
	return lgg;
	}
	
}
