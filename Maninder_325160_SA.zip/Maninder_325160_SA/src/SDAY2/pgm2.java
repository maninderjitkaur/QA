 
package SDAY2;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://www.facebook.com");
//		dr.findElement(By.id("email")).sendKeys("mkriar97@gmail.com");
//
//		dr.findElement(By.name("pass")).sendKeys("(Sandy23)!1995.F");
//
//		dr.findElement(By.id("loginbutton")).click();
		WebElement we1=dr.findElement(By.id("day"));
		Select sel=new Select(we1);
		sel.selectByVisibleText("25");
		
		WebElement we2=dr.findElement(By.id("month"));
		Select sel1=new Select(we2);
		sel1.selectByVisibleText("Aug");
		
		WebElement we3=dr.findElement(By.id("year"));
		Select sel2=new Select(we3);
		sel2.selectByVisibleText("1997");
		String title=dr.getTitle();
		System.out.println("title: "+title);
		
		List rb=dr.findElements(By.name("sex"));
		((WebElement)rb.get(0)).click();
		String a_profile=dr.findElement(By.className("_1vp5")).getText();
		String e_profile="Maninder";
		if(a_profile==e_profile) {
			System.out.println("rigth");
		}
		else {
			System.out.println("wrong");
		}
	}

}

