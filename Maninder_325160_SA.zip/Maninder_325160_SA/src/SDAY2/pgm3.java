package SDAY2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class pgm3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("https://www.w3schools.com/html/html_tables.asp");
//		String s=dr.findElement(By.xpath("//*[@id=\"customers\"]/tbody/tr[1]/th[1]")).getText();
//		System.out.println(s);
		
		String s=dr.findElement(By.xpath("//*[@id=\"customers\"]/tbody/tr[5]/td[1]")).getText();
		System.out.println(s);
		String s1=dr.findElement(By.xpath("//*[@id=\"customers\"]/tbody/tr[6]/td[2]")).getText();
		System.out.println(s1);
		
	}

}
