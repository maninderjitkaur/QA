package CUM_TEST_RUNNER;

import org.testng.annotations.Test;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;
@CucumberOptions(features="FEATURES",glue="CUM_STEP_DEF",
						tags="@round1",
						plugin="html:reports/cucumber-report")
public class testrunner extends AbstractTestNGCucumberTests {
  
}
