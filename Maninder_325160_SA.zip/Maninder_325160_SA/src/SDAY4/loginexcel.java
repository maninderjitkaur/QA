package SDAY4;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import SDAY5.data;

public class loginexcel {
	data lg;
	ArrayList<data> al;
	public ArrayList<data> read(){
		al=new ArrayList<data>();
		for(int i=1;i<=2;i++) {
		lg=new data();
		try {
			File f=new File("C:\\training\\prac1.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb= new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet4");
			XSSFRow r=sh.getRow(i);
			XSSFCell c=r.getCell(0);
			lg.uid=(String)c.getStringCellValue();
//			System.out.println(ld.uid);
			
			XSSFCell c1=r.getCell(1);
			lg.pass=(String)c1.getStringCellValue();

			
			XSSFCell c2=r.getCell(2);
			lg.exr=(String)c2.getStringCellValue();
			if(!(lg.exr).contains(("SUCCESS")))
			{
			
			XSSFCell c3=r.getCell(3);
			lg.exem1=(String)c3.getStringCellValue();
			
			XSSFCell c4=r.getCell(4);
			lg.exerm2=(String)c4.getStringCellValue();
			}
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}}
		return al;
	}

	public  void login()
	{
	System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
	WebDriver dr=new ChromeDriver();
	dr.get("http://demowebshop.tricentis.com/");
	dr.findElement(By.className("ico-login")).click();
	
	dr.findElement(By.id("Email")).sendKeys(lg.uid);
	dr.findElement(By.id("Password")).sendKeys(lg.pass);
//	dr.findElement(By.className("button-1 login-button")).click();
	dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
//	String s=dr.findElement(By.className("account")).getText();
	
	boolean f=dr.getTitle().contains("Login");
//	System.out.println(f);
	if(!f) {
		lg.acr="SUCCESS";
		
		System.out.println("login successfull");
		lg.trslt="PASS";
	}
	else {
		lg.acr="FAILURE";
//		System.out.println("lg.exem1"+"---"+"lg.exerm2");
		lg.acem1=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/span")).getText();
		lg.acem2=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/ul/li")).getText();
		if(lg.exr.contains("FAILURE")) {
//			System.out.println(lg.exem1);
//			System.out.println(lg.acem1);
//			System.out.println(lg.exerm2);
//			System.out.println(lg.acem2);
			
		if(lg.exem1.equals(lg.acem1)&&(lg.exerm2.equals(lg.acem2))) {
			lg.trslt="PASS";
		}}
		
		
		else {
			lg.trslt="FAIL";
		}
	}
	}
	void write(int i) {
		
		try {
			File f=new File("C:\\training\\prac1.xlsx");
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb= new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet4");
		
				
				XSSFRow r=sh.getRow(i);
				XSSFCell c=r.createCell(5);
				c.setCellValue((String)lg.acr);
//				System.out.println(lg.acr);
				if(!lg.acr.contains("SUCCESS")) {
				
				XSSFCell c1=r.createCell(6);
				c1.setCellValue((String)lg.acem1);
				
				XSSFCell c2=r.createCell(7);
				c2.setCellValue((String)lg.acem2);}
				
				XSSFCell c3=r.createCell(8);
				c3.setCellValue((String)lg.trslt);
				System.out.println(lg.trslt);
				
				
				
		
			FileOutputStream fos=new FileOutputStream(f);
			wb.write(fos);
		}catch (IOException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
}
