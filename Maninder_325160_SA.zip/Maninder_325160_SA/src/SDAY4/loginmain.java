package SDAY4;

public class loginmain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		loginexcel lx=new loginexcel();
		for(int i=1;i<=2;i++){
		lx.read();
		lx.login();
		lx.write(i);
	}

}
}