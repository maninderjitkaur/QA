package SDAY88;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class NewTest {
	  String autURL;
	  String nodeURL;
	  WebDriver dr;
  @BeforeClass
  public void setup()throws MalformedURLException {
	  autURL="https://www.facebook.com";
	  nodeURL = "http://172.16.29.206:5566/wd/hub";
	 DesiredCapabilities cap=DesiredCapabilities.firefox();
	//  FirefoxOptions cap = new FirefoxOptions();
	  cap.setBrowserName("firefox");
	  cap.setPlatform(Platform.WINDOWS);
	  dr=new RemoteWebDriver(new URL(nodeURL),cap);
	  
  }
  @Test
  public void t1() {
//	  dr.get("http://www.facebook.com");
  }
  @Test
  public void t2() {
	  dr.get("http://demowebshop.tricentis.com/login");
  }
}
