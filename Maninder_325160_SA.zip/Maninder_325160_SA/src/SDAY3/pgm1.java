package SDAY3;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("https://ultimateqa.com/simple-html-elements-for-automation/");
		dr.findElement(By.name("button1")).click();
		String s=dr.findElement(By.className("entry-title")).getText();
//		
		String s1="Button success";
		if(s.equals(s1)) {
			System.out.println("worked");
		}
		else {
			System.out.println("notworking");
		}
	}

}
