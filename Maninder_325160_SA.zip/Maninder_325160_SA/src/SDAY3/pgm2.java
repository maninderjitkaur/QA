package SDAY3;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class pgm2 {
	public static void register() {
		System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/");
		dr.findElement(By.className("ico-register")).click();
		if(dr.findElement(By.id("gender-female")).isSelected())
		{
			
		}
		else {
			dr.findElement(By.id("gender-female")).click();
		}
		dr.findElement(By.id("FirstName")).sendKeys("Maninder");
		dr.findElement(By.id("LastName")).sendKeys("K");
		dr.findElement(By.id("Email")).sendKeys("dodger.torris@iiron.us");
		dr.findElement(By.id("Password")).sendKeys("Sel123");
		dr.findElement(By.id("ConfirmPassword")).sendKeys("Sel123");
		dr.findElement(By.id("register-button")).click();
		String s=dr.findElement(By.className("account")).getText();
		String s1="dodger.torris@iiron.us";
		if(s1.equals(s)) {
			System.out.println("done");
		}
		else {
			System.out.println("not");
		}
		
		
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		register();
		
	}

}
