package SDAY3;

public class logindata {
	String uid;
	String pass;
	String exr;
	String acr;
	String tres;

}
