package SDAY3;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class testlogin {
	public static logindata ld;
	
	public static void login()
	{
	System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
	WebDriver dr=new ChromeDriver();
	dr.get("http://demowebshop.tricentis.com/");
	dr.findElement(By.className("ico-login")).click();
	
	dr.findElement(By.id("Email")).sendKeys(ld.uid);
	dr.findElement(By.id("Password")).sendKeys(ld.pass);
//	dr.findElement(By.className("button-1 login-button")).click();
	dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
	String s=dr.findElement(By.className("account")).getText();
	if(s.equals(ld.uid)) {
		ld.acr="success";
		ld.tres="pass";
	}
	else {
		ld.acr="error";
	}

	}
	public static void read() {
		ld=new logindata();
		try {
			File f=new File("C:\\training\\logintestdata.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb= new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			XSSFRow r=sh.getRow(1);
			XSSFCell c=r.getCell(0);
			ld.uid=(String)c.getStringCellValue();
//			System.out.println(ld.uid);
			
			XSSFCell c1=r.getCell(1);
			ld.pass=(String)c1.getStringCellValue();
//			System.out.println(ld.pass);
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void write() 
	{
		int row=1;
		try {
			File f=new File("C:\\training\\logintestdata.xlsx");
			FileInputStream fis = new FileInputStream(f);
			XSSFWorkbook wb= new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
		
				
				XSSFRow r=sh.getRow(row);
				XSSFCell c=r.createCell(3);
				c.setCellValue((String)ld.acr);
				
				XSSFCell c1=r.createCell(4);
				c1.setCellValue((String)ld.tres);
				
				
				
		
			FileOutputStream fos=new FileOutputStream(f);
			wb.write(fos);
		}catch (IOException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		read();
		login();
		
		write();
		
		
		
		

	}

}
