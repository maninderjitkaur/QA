package SDAY7;

import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel_operation3 {
	public String read_excel(int n, int i) {
		// TODO Auto-generated method stub
		String s = null;
			try {
				
				File f=new File("C:\\training\\keydatadriven.xlsx");
				FileInputStream fis=new FileInputStream(f);
				XSSFWorkbook wb= new XSSFWorkbook(fis);
				XSSFSheet sh=wb.getSheet("Sheet1");
				XSSFRow r=sh.getRow(n);
				XSSFCell c=r.getCell(i);
				s=(String)c.getStringCellValue();
//				System.out.println(ld.uid);
				
				
				}
				
	
	catch(Exception e) {
		System.out.println(e);
	}
		return s;
	}
}
