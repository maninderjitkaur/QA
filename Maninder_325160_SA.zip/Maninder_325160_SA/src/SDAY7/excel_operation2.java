package SDAY7;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import SDAY5.data;

public class excel_operation2 {

	public String read_excel(int n, int i) {
		// TODO Auto-generated method stub
		String s = null;
			try {
				
				File f=new File("C:\\training\\keydatadriven.xlsx");
				FileInputStream fis=new FileInputStream(f);
				XSSFWorkbook wb= new XSSFWorkbook(fis);
				XSSFSheet sh=wb.getSheet("Sheet1");
				XSSFRow r=sh.getRow(n);
				XSSFCell c=r.getCell(i);
				s=(String)c.getStringCellValue();
//				System.out.println(ld.uid);
				
				
				}
				
	
	catch(Exception e) {
		System.out.println(e);
	}
		return s;
	}
	

}
