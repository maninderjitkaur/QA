package SDAY7;

import org.openqa.selenium.WebDriver;

import SDAY6.all_webelement_fnc;
import SDAY6.excel_operation;

public class kwdrvn2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String kw,loc,td;
		WebDriver dr=null;
		all_webelement_fnc2 we=new all_webelement_fnc2(dr);
		excel_operation2 excel=new excel_operation2();
		for(int r=1;r<=3;r++) {
			kw=excel.read_excel(r,1);
			loc=excel.read_excel(r,2);
			td=excel.read_excel(r,3);
		
		switch(kw){
			case "launchbrowser" :
				we.launchChrome(td);
				break;
			case "enter_txt" :
				we.enter_txt(loc,td);
				break;
			case "click_btn" :
				we.click(loc);
				break;
			
		}}

	}

}
