package SDAY10;

public class tc_selection {
	public static String tcid;
	public static String flag;
	public static int no_step;
	public static String test_data_sh;
	
}
