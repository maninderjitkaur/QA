package SDAY10;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel_read {
	public static String filename="C:\\training\\hfw.xlsx";
	public static String kw_sheet="KEYWORD";
	public static String tc_sheet="TC_SELECTION_SH";
	public static XSSFSheet kw_sh_obj,tc_sh_obj,td_sh_obj;
	public static ArrayList<login_test_data> td_al;
	public static XSSFSheet set_sheet(String sheetname) {
		XSSFSheet sh=null;
		try {
			File f=new File(filename);
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			sh=wb.getSheet(sheetname);
		}catch(IOException e) {
			e.printStackTrace();
		}return sh;
	}
	public static tc_selection read_TC_SELECTION_SH(int j) {
			tc_selection td=new tc_selection();
		try {
			tc_sh_obj=set_sheet(tc_sheet);
			XSSFRow rw=tc_sh_obj.getRow(j);
			td.tcid=rw.getCell(0).getStringCellValue();
			td.flag=rw.getCell(1).getStringCellValue();
			td.no_step=(int)rw.getCell(2).getNumericCellValue();
			td.test_data_sh=rw.getCell(3).getStringCellValue();
			
			
		}
		
		catch(Exception e) {
			e.printStackTrace();
		}return td;
	}
	
}
