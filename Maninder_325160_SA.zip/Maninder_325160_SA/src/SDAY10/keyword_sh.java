package SDAY10;

public class keyword_sh {
	String tc,id,step,kwd,xp,tdata,tres;
}
