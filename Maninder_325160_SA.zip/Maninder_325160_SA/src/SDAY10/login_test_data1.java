package SDAY10;

public class login_test_data1 {

	public String uid;

	public String pwd;
}
