package SDAY10;

public class HFW extends excel_read{
	static keyword_sh d=new keyword_sh();
	static tc_selection td=new tc_selection();
	static String filename="C:\\training\\hfw.xlsx";
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String id,ch,testdata=null;
		int i,j,k=0;
		for(i=1;i<=3;i++) {
			td=read_TC_SELECTION_SH(i);
			if((td.flag).equals("Y")){
				System.out.println(td.tcid);
			}
		}
	}

}
