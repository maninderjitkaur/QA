package DAY4;

public class pgm3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			String s="i am working with globallogic in noida";
			String s1,arr[]=new String[7];
			int p=0,p1=0,i=0;;
			while(p<s.length()) {
				p=s.indexOf(" ",p+1); 
				
				if(p!=-1) {
//					System.out.print(p+" ");
					s1=s.substring(p1,p);
//					System.out.println(s1);
					arr[i]=s1;
//					System.out.println(arr[i]);
					i++;
					p1=p+1;
				}
				else {
					p=s.length();
					s1=s.substring(p1,p);
//					System.out.println(s1);
					arr[i]=s1;
				}
				
			}
			for( i=0;i<arr.length;i++) {
				System.out.println(arr[i]);
			}
			
			
			
			

	}

}
