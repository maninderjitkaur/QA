package DAY4;

public class pgm6 {
	public int add(int x,int y) {
		int m=x+y;
		return m;
		}
	public float add(float x,int y) {
		float z=x+y;
		return z;
	}
}
;