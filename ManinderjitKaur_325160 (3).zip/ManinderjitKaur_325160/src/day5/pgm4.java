package day5;

import DAY7.Student;

public class pgm4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for( int i=1;i<3;i++) {
		operations op = new operations();
		Student s1=op.read_excel(i);
		s1.Avg();
		op.write_excel(s1, i);
		}

	}

}
