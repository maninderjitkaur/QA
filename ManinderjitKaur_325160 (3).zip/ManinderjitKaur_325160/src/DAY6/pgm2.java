package DAY6;
import java.util.ArrayList;


public class pgm2 {
	ArrayList <Student> st=new ArrayList<Student>();
	public void create_al() {
		Student s1=new Student("ramesh",101,80,95);
		Student s2=new Student("suresh",102,85,87);
		st.add(s1);
		st.add(s2);
	}
	public void display_al() {
		for(Student s:st) {
			System.out.println("NAME:"+s.name
					+",rollno:"+s.rollno
					+",sel:"+s.sel
					+",jav:"+s.jav
					+",avg:"+s.avg
					);
		}
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	pgm2 obj=new pgm2();
	obj.create_al();
	obj.display_al();
		
		

	}

}
