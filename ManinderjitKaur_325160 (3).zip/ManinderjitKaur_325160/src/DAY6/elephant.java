package DAY6;

public class elephant extends Animal{
	int lot;
	int lotk;
	public void load() {
		System.out.println("elephant loads weight");
	}
	public void water() {
		System.out.println("elephant can store water");
	}
	public elephant(int age,String name,String color,String food,String gender,int trunk,int tusks) {
		this.lot=trunk;
		this.lotk=tusks;
		this.age=age;
		this.color=color;
		this.food=food;
		this.gender=gender;
		this.name=name;
		
	}
	public void display() {
		System.out.println("Age:"+this.age+"  Name:"+this.name+"  color:"+this.color+
				"  food:"+this.food+"  gender:"+this.gender
				+" length of trunk:"+this.lot+" length of tucks"+this.lotk);
	}
}
