package DAY6;

public class major {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		elephant el=new elephant(22,"taniya","ligth brown","veg","female",10,10);
//		tiger t=new tiger(15, 5, 22, " brown", "nonveg", "female","Akash");
		el.display();
		tiger t=new tiger(15, 5, 22, " brown", "nonveg", "female","Akash");
		t.display();
	}

}
//Age:"+this.age+"  Name:"+this.name+"  color:"+this.color+
//	"  food:"+this.food+"  gender:"+this.gender
//	+" length of trunk:"+this.lot+" length of tucks"+this.lotk