package DAY6;
//just extended for loop 
public class pgm3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int ar1[]= {1,2,3,4,5};
		for( int i:ar1) {
			System.out.println(i);
		}
		
	}

}
