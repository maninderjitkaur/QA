package DAY6;

public class Animal {

	
		
		int age;
//		int nol;
		String name;
		String color;
		String food;
		String gender;
		public void eat() {
		 System.out.println("animal eats");	
		}
		public void walk() {
			 System.out.println("animal walks");
		}
		public void run() {
			 System.out.println("animal runs");	
		}
		public void display() {
			
		}
		

	

}
