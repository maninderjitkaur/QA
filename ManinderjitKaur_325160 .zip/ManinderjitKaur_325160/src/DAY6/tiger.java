package DAY6;

public class tiger extends Animal{
	int lenteeths;
	int lenclaws;
	public void roar() {
		System.out.println("tiger roars");
	}
	public void climb() {
		System.out.println("tiger climbs");
	}
	public void maul() {
		System.out.println("tiger mauls");
	} 
	public tiger(int lott,int loc,int age, String color,String food,String gender,String name) {
		this.lenteeths=lott;
		this.lenclaws=loc;
		this.age=age;
		this.color=color;
		this.food=food;
		this.gender=gender;
		this.name=name;
	}
	public void display() {
		System.out.println("Age:"+age+"  Name:"+name+"  color:"+color+
				"  food:"+food+"  gender:"+gender+"  length ofteeths:"+lenteeths
				+" lenclaws:"+lenclaws);
	}


}
