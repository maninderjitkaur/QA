package DAY6;

import java.util.ArrayList;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		String str[]= {"hi", "hello"};
//		for(String s: str) {
//			System.out.println(s);
//		}
		ArrayList<String> al=new ArrayList<String>();
		al.add("a");
		al.add("b");
		al.add("c");
		System.out.println("before adding");
		for(String s: al) {
			System.out.println(s);
		}
		al.add(1,"d");
		System.out.println("after adding");
		for(String s: al) {
			System.out.println(s);
		}
	
		al.remove(1);
		System.out.println("after deletion");
		for(String s: al) {
			System.out.println(s);
		}
//		al.get(1);
	}

}
