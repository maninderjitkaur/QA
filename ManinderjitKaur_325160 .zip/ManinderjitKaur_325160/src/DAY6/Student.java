package DAY6;

public class Student {
 public int rollno;
 public String name;
 public int sel;
 public int jav;
 public float avg;
public void Avg() {
//	this.avg=(float) (this.sel+this.jav)/2;
	this.avg=(float) (this.sel+this.jav/2);
}
	
public Student(String name, int rollno, int sel, int jav) {
	// TODO Auto-generated constructor stub
	this.name=name;
	this.rollno=rollno;
	this.sel=sel;
	this.jav=jav;
	Avg();
}
}

