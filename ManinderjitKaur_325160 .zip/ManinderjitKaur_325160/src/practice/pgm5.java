


package practice;

public class pgm5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Parrots p1 = new Parrots(59,3000,80,"blue","fruits","male","AP",2);
		Parrots p2 = new Parrots(62,4000,40," Red","seeds","female","BP",2);
		Parrots p3 = new Parrots(8,12,20,"green","insects","male","CP",2);
		Owl o1 = new Owl(40,620,3,"yellow","squirrels","female","AO",2);
		Owl o2= new Owl(70,2000,4,"orange","insects","male","BO",2);
		
		p1.display();
		p1.eats();
		p1.flys();
		p2.display();
		p2.imitate();
		p2.flys();
		p3.display();
		p3.eats();
		p3.screams();
		
		o1.display();
		o1.eats();
		o1.rotatesneck();
		o2.display();
		o2.hunts();
		
		

	}

}
