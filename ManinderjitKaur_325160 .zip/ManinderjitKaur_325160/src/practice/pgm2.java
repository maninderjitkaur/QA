package practice;

import java.util.ArrayList;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Integer> al=new ArrayList<>();
		for(int i=10;i<=30;i++) {
			if(i%2==0) {
				al.add(i);
			}
		}
		for(int i:al) {
			System.out.println(i);
		}

	}

}
