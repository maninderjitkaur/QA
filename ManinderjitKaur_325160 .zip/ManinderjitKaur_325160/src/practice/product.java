
package practice;

public class product {
	int pid;
	String pname;
	int urate;
	int up;
	
	int price;
	String grade;
	
	public void price() {
		this.price=urate*up;
	}
	
	public void grade(product p) {
		if(p.price<25000)
			this.grade="GradeA";
		else if (p.price>25000)
			this.grade="GradeB";
	}

}



