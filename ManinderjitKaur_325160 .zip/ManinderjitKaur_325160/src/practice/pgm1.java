package practice;
//5 amstrong no.
public class pgm1 {
	int arr[]=new int[5];
	int sum=0,j=0,var,rem;
		int[] ams() {
		for(int i=0;i<1000;i++) {var=i;
			sum=0;
			while(var!=0) {
				rem=var%10;
				sum+=rem*rem*rem;
				var=var/10;
				}
			
			if(sum==i) {

				arr[j]=i;
				j++;

			
			}
			if(j==5) {
				break;
			}
			
		}return arr;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		pgm1 obj=new pgm1();
		int ar1[]=new int[5];
		ar1=obj.ams();
		for(int i:ar1) {
			System.out.println(i);
		}
		
	}

}
