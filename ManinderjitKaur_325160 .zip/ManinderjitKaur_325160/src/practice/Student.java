package practice;

public class Student {
	int rollno;
	String name;
	int java;
	int sel;
	float avg;
	void average() {
		this.avg=(float) (java+sel)/2;
	}
	Student (int rollno,String name,int java ,int sel){
		this.rollno=rollno;
		this.name=name;
		this.java=java;
		this.sel=sel;
		average();
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student s1=new Student(1,"raj",89,94);
		Student s2=new Student(2,"ram",84,92);
		Student s3=new Student(1,"raj",83,97);
		System.out.println(s1.avg);
		System.out.println(s2.avg);
		System.out.println(s3.avg);
		
	}

}
