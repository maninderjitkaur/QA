package DAY4;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=1;
		for (int i=0;i<4;i++) 
		{
			char var='1';
			for(int j=0;j<6-2*i;j++)
			{
				System.out.print("*");
			}int count=0;
			for(int k=0;k<num;k++)
			{
				System.out.print(var);
				
				if(var=='1'||count>0)
				{
					var='*';
					count++;
					//System.out.print(var);
				} if(count==4) 
				{
					var='1';
					count=0;
				}
			}num+=4;
			for(int j=0;j<6-2*i;j++)
			{
				System.out.print("*");
			}
			System.out.println();
		}

	}

}
