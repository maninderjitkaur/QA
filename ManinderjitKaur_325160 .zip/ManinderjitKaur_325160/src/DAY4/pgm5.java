package DAY4;

public class pgm5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		pgm6 obj=new pgm6();
		int a=obj.add(5, 6);
		System.out.println(a);
		float b=obj.add(5.6f, 8);
		System.out.println(b);
		
			
		

	}

}
