package DAY4;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int jmax=4,kmax=1;
		for(int i=1;i<=3;i++) {
			for(int j=1;j<=jmax;j++) {
				System.out.print("*");
			}
			for(int k=1;k<=kmax;k++) {
				System.out.print("1*");
			}
			jmax-=2;
			kmax+=1;
			System.out.println();
		}

	}

}
