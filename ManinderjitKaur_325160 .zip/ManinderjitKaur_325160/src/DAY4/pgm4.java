package DAY4;

public class pgm4 {
	int id;
	String name;
	int m1;
	public pgm4(int id,String name,int m1) {
		this.id=id;
		this.name=name;
		this.m1=m1;
	}
	public void display()
	{
		System.out.println("NAME:"+name);
		System.out.println("id:"+id);
		System.out.println("m1:"+m1);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		pgm4 s1=new pgm4(101,"akash",89);
		
//		System.out.println(s1.name);
//		System.out.println(s1.id);
//		System.out.println(s1.m1);
		s1.display();
		

	}

}
