package DAY7;

import java.util.ArrayList;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		arraylistexcel obj=new arraylistexcel();
		ArrayList<Student> sal=new ArrayList<>();
		sal=obj.read_excel();
		obj.write_excel(sal);
	}

}
