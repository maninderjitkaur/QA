package DAY7;

public class Student {
 public int rollno;
 public String name;
 public int m1;
 public int m2;
 public float avg;
public void Avg() {
	this.avg=(float) (this.m1+this.m2)/2;
}
}
