package day5;

public class pgm1i {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			int num[]= {1,2,3};
			int a=num[3];
			System.out.println(a);
			
//			System.out.println();
		}
		
		
		catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("ArrayIndexOutOfBoundsException handled");
		}try {
			int n1=5,n2=0,n3;
			n3=n1/n2;
			System.out.println(n3);
		}
		
		catch(ArithmeticException ex) {
			System.out.println("ArithmeticException handled");
		}
		
		

	}

}
