package day5;

public class check {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char var='1';
		int count=0;
		for(int k=0;k<(2*3);k++)
		{
			System.out.print(var);
			
			if(var=='1'||count>0)
			{
				var='*';
				count++;
				//System.out.print(var);
			} if(count==4) 
			{
				var='1';
				count=0;
			}
		}
	}

}
