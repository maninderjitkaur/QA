package day5;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			File f=new File("C:\\Desktop\\sample.xlsx");
			FileInputStream fs=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fs);
			XSSFSheet sh=wb.getSheet("Sheet1");
			XSSFRow r=sh.getRow(1);
			XSSFCell c=r.getCell(0);
			String s=c.getStringCellValue();
			System.out.println(s);
			
		} catch(FileNotFoundException e) {
			//e.printStackTrace();
			System.out.println(e);
		}
		catch(IOException e) {
			
			e.printStackTrace();
		}

	}

}
