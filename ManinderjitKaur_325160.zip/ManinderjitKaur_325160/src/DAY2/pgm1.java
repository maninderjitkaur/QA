package DAY2;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int s=5;
		switch(s) {
		case 5:{
			System.out.println("five");
//			break;
		}
		case 6:{
			System.out.println("six");
			break;
		}
		default:
		{
			System.out.println("no match");
			break;
			
		}
			
		}
		System.out.println("out of switch");

	}

}
