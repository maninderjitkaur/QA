package DAY2;

public class pgm10 {
	
	public static boolean isPrime(int k) {     //number should be parameter
		for(int j=2;j<=k/2;j++)               //j<
		{
			if(k%j==0) {
				return false;
			}
		}System.out.println(k);
		return true;
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(2);
		int n=1;int sum=2;int i=3;
	while(n<10) {
		
		if(isPrime(i)==true) {
			sum+=i;
			n++;
		}i++;
		
	}
	System.out.println("sum :"+sum);

	}

}
