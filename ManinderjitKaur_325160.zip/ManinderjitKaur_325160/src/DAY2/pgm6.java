package DAY2;

public class pgm6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=3666773;
		int sum=0;
		while(num>=1) {
			int rem=num%10;
			if(rem>5) {
				sum+=rem;
			}num=num/10;
			
		}
		System.out.println(sum);

	}

}
