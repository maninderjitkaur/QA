package DAY2;

public class pgm4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int count1=4; int num=4;int num2=1;
		for(int i=0;i<5;i++) {

			
			for(int j=0;j<num;j++) {
				System.out.print(" ");
			}
			num--;
			for(int k=1;k<=num2;k++) {
				System.out.print(k);
				
			}num2++;
			System.out.println("");
		}
		

	}

}
