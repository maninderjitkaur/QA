package DAY2;

public class pgm9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a,b=100,c=59;
		a=add(b,c);
		System.out.println("sum of"+b+"and"+c+"="+a);

	}
	public static int add(int x,int y) {
		int z=x+y;
		return z;
	}

}
