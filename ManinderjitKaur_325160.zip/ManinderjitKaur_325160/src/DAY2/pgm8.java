package DAY2;

public class pgm8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//int num1=5,num2=4;
//		for(int i=num1;i<=9;i++) {
//			for(int j=num2;j<=12;j++) {
//				if(j%2!=0) {
//					
//				}else {
//					System.out.println(i+"*"+j+"="+i*j);
//				}
//			}
//		}
		int num1=5,num2=4;
		for(int i=0;i<5;i++) {
			System.out.println(num1+"*"+num2+"="+(num1*num2));
			num1+=1;
			num2+=2;
		}

	}

}
