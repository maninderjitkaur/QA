package DAY1;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num1=13131,num2=0;
		int num=num1;
		int s;
		int count=1;
		while(num>10) {
			count++;
			num=num/10;
		}num=num1;

		for(int i=0;i<count;i++)
		{
			s=num%10;
			num2=num2*10+s;
			num=num/10;
		}
		System.out.println(num2);

		if(num2==num1) {
			System.out.println("palindrome");
	
		}
		else {
			System.out.println("no");
		}
	}

}
