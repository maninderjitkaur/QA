package DAY1;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		System.out.println("java");
		int count=2;
//		int sum=0;
		int line=1;
		System.out.println(count);
		for (int i=3;i<50;i++)
		{int count1=1;
			for(int j=2;j<i;j++) 
			{
				if(i%j!=0) 
				{
				count1++;	
				}
				else 
				{break;}
				if(count1==i-1) {
//					sum+=count1;
					System.out.println(i);
					count+=count1;
					line++;
					
				}if(line==10) {
					break;
				}
			}
		}
		System.out.println("sum is:"+count);
	}

}
