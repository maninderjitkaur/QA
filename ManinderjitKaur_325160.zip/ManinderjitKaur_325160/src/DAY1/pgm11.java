package DAY1;

import java.util.Scanner;

public class pgm11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		int b=sc.nextInt();
		int c=sc.nextInt();
//		int avg=(a+b+c)/3;
//		System.out.println(avg);
//		if(a >avg) {
//			System.out.println(a +"is greater");
//		}
//		else {
//			System.out.println(a +"is smaller");
//		}
//		if(b>avg) {
//			System.out.println(b +"is greater");
//		}
//		else {
//			System.out.println(b +"is smaller");
//		}
//		if(c >avg) {
//			System.out.println(c +"is greater");
//		}
//		else {
//			System.out.println(c +"is smaller");
//		}
		int small=1000000000,big=0;
		if(a>big) {
			big=a;
		}
		if(b>big) {
			big=b;
		}if(c>big) {
			big=c;
		}
		if(a<small) {
			small=a;
		}
		if(b<small) {
			small=b;
		}if(c<small)
		{
			small=c;
		}
		System.out.println(big+"is greatest  "+small+"is smallest");

	}

}
