package DAY1;

public class pgm10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char var='z';
		if(var=='a'||var=='e'||var=='i'||var=='o'||var=='u') {
			System.out.println(var  +" is a vowel");
		}
		else {
			System.out.println(var +" is alphabetic");
		}
		char var1='e';
		if(var1=='a'||var1=='e'||var1=='i'||var1=='o'||var1=='u') {
			System.out.println(var1  +" is a vowel");
		}
		else {
			System.out.println(var1 +" is alphabetic");
		}

	}

}
