package DAY3;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum=0;
		float avg;
		int std[]= {77,85,91,79,65,92};
		for(int i=0;i<=5;i++) {
			sum+=std[i];
		}
		avg=(float) (sum/6.0);
		System.out.println(avg);

	}

}
