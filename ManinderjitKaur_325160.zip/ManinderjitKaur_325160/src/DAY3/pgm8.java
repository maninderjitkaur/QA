package DAY3;

public class pgm8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="i am learning java";
		int c=0,p=0;
		while(p>=0) {
			p=s.indexOf(" ",p+1);
			if(p!=-1) {
				System.out.print(p+" ");
				c++;
			}
			else {
				p=-1;
			}
		}System.out.println("");
		System.out.println("no. of spaces:"+c);

	}

}
