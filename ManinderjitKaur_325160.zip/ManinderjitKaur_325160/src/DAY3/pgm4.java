package DAY3;

public class pgm4 {
	public static int max(int ar1[])
	{
		int var=0;

		for(int i=0;i<ar1.length;i++) {
			if(ar1[i]>var) {
				var=ar1[i];

			}
		}
		return var;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int arr[][]= {{81,88,92,28},{78,99,78,91},{80,95,84,167}};
		for(int i=0;i<=2;i++) {
			for(int j=0;j<=3;j++) {
				System.out.print(arr[i][j]+" ");
			}System.out.println("");
		}
		
		for(int i=0;i<=2;i++) {int ar1[]=new int[4];
			for(int j=0;j<=3;j++) {
				ar1[j]=arr[i][j];
			}

			int var=max(ar1);
			System.out.println("max value of row "+i+"is"+var);
		}
		

	}

}
