package DAY3;

public class Student {
int id;
String name;
int m1;
int m2;
float avg;
public void Avg() {
	this.avg=(float) (this.m1+this.m2)/2;
}
}
