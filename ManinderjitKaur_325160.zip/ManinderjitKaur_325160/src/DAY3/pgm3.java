package DAY3;

public class pgm3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]= {21,34,91,59,16,44,29,36,49,31};
		for(int i=0;i<arr.length;i++) {
//			int sum=0;
			for(int j=i+1;j<arr.length;j++) {
				if((arr[i]+arr[j])==65) {
					System.out.println("sum of "+arr[i]+" and "+arr[j]+"="+"65");
				}
			}
		}
	}
}
