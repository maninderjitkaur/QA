package DAY3;

public class A {
	int abc;
	public void show1() {
		System.out.println(this.abc);
	}

}
