package DAY3;

public class College {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student Rakesh=new Student();
		Rakesh.id=101;
		Rakesh.name="rakesh";
		Rakesh.m1=81;
		Rakesh.m2=81;
		Rakesh.Avg();
		System.out.println(Rakesh.avg);
		Student priya=new Student();
		priya.id=102;
		priya.name="priya";
		priya.m1=86;
		priya.m2=89;
		priya.Avg();
		System.out.println(priya.avg);
		
	}

}
