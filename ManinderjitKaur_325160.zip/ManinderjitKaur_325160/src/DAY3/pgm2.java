package DAY3;

public class pgm2 {
	public static boolean isEven(int value) {
		if(value%2==0) {
			return true;
		}return false;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		boolean var=false;
		int sum=0;
		int arr[]= {21,34,91,59,16,25,29,74,49,82};
		for(int i=0;i<arr.length;i++) {
			var=isEven(arr[i]);
			if(var==true) {
				sum+=arr[i];
			}
			
		}
		System.out.println(sum);

	}

}
