package DAY3;

public class pgm7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="Noida",s2="noida",s3="i am learning java",s4;
		int l=s1.length();
		System.out.println(l);
		int r=s1.compareTo(s3);
		System.out.println(r);
		s4=s3.substring(2,7);
		System.out.println(s4);
		int i=s3.indexOf("q");
		System.out.println(i);
	}

}
