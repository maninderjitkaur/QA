package Poc4;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class info_page {
	WebDriver dr;
	public info_page( WebDriver dr)
	{
		this.dr=dr;
		PageFactory.initElements(dr, this);
	}
//	void enter_info(String fname,String lname,String pin)
//	{
//		dr.findElement(By.xpath("//*[@id=\"first-name\"]")).sendKeys(fname);
//		dr.findElement(By.xpath("//*[@id=\"last-name\"]")).sendKeys(lname);
//		dr.findElement(By.xpath("//*[@id=\"postal-code\"]")).sendKeys(pin);
//		dr.findElement(By.xpath("//*[@id=\"checkout_info_container\"]/div/form/div[2]/input")).click();
//		
//	}
	public void enter_info(String fname, String lname, String pin) {
		// TODO Auto-generated method stub
		dr.findElement(By.xpath("//*[@id=\"first-name\"]")).sendKeys(fname);
		dr.findElement(By.xpath("//*[@id=\"last-name\"]")).sendKeys(lname);
		dr.findElement(By.xpath("//*[@id=\"postal-code\"]")).sendKeys(pin);
		dr.findElement(By.xpath("//*[@id=\"checkout_info_container\"]/div/form/div[2]/input")).click();
	}
}
