package Poc4;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

//import SDAY9.cart_page;
//import SDAY9.home_page;
//import SDAY9.login_page;

public class NewTest1 {
	WebDriver dr;
	login_page lp;
	Product p;
	cart_page cp;
	info_page ip;
	checkout_page op;
	
	@BeforeClass
	  public void bc() {
		  
		  System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
			dr = new ChromeDriver();
			dr.get("https://www.saucedemo.com/");
			lp = new login_page(dr);
			p= new Product(dr);
			cp=new cart_page(dr);
			ip=new info_page(dr);
			op=new checkout_page(dr);
	  }

	 @Test
	 public void f1() {
		 String id1="standard_user";
		 String pass1="secret_sauce";
		 lp.login(id1,pass1);
		 String ac="Products";
		 String exp=dr.findElement(By.xpath("//*[@id=\"inventory_filter_container\"]/div")).getText();
		
		 SoftAssert sa=new SoftAssert();
		 
		 
		 sa.assertEquals(ac,exp);
		 sa.assertAll();
	 }
	 
  
  
  @DataProvider(name="product")
  public String[] getdata1() {
	  String [] data = {"Sauce Labs Bolt T-Shirt"};
	return data;
  }
  @Test(dataProvider="product")
  public void f2(String pr) {

	  p.add_product(pr);
	  p.click_cart();
  }
  @Test
  public void f3() {
	  String ac=cp.verify();
	  cp.click_cont();
	  String exp=cp.ap1.get(0).name;
//	  System.out.println(ac+"+"+exp);
	  SoftAssert sa=new SoftAssert();
	  sa.assertEquals(ac,exp);
	  sa.assertAll();
	  
	 
  }
  @Test
  public void f4() {
	  ip.enter_info("m","k","123");
  }
  @Test
  public void f5() {
	  float f=op.overview();
	  float fprice=f+cp.ap1.get(0).price;
	  String total=dr.findElement(By.xpath("//*[@id=\"checkout_summary_container\"]/div/div[2]/div[7]")).getText();
	 String[] ar=total.split(":");
	 float ap=Float.valueOf(ar[1]);
  }


 
}
