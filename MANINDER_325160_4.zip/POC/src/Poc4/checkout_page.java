package Poc4;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class checkout_page {
	WebDriver dr;
	cart_page cp;
	public checkout_page(WebDriver dr){
		this.dr=dr;
		PageFactory.initElements(dr, this);
	}
	public float overview() {
		// TODO Auto-generated method stub
		String tax;
		int taxint;
		float f = 0;
		String ac=dr.findElement(By.xpath("//*[@id=\"item_1_title_link\"]/div")).getText();
		String exp=cp.ap1.get(0).name;
		if(ac.equals(exp)) {
			tax=dr.findElement(By.xpath("//*[@id=\"checkout_summary_container\"]/div/div[2]/div[6]")).getText();
			String[] sar=tax.split(":");
			 f=Float.valueOf(sar[1]);
	
			
		}		return f;
	}
	
	
}
