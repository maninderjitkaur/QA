package Poc4;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class cart_page  {
	WebDriver dr;
	public cart_page(WebDriver dr){
		this.dr=dr;
		PageFactory.initElements(dr, this);
	}
	ArrayList<Product> ap1=new ArrayList<Product>();
	void add() {
		Product p6=new Product("Sauce Labs Bolt T-Shirt",15.99f,"//*[@id=\"inventory_container\"]/div/div[3]/div[3]/button");
		ap1.add(p6);
	}
	public String verify() {
		// TODO Auto-generated method stub
		add();
//		dr.findElement(By.xpath("//*[@id=\"shopping_cart_container\"]/a/svg/path")).click();
		String ac=dr.findElement(By.xpath("//*[@id=\"item_1_title_link\"]/div")).getText();
	
//		dr.findElement(By.xpath("//*[@id=\"cart_contents_container\"]/div/div[2]/a[2]")).click();
	
		return ac;
	}

	public void click_cont() {
		// TODO Auto-generated method stub
		dr.findElement(By.xpath("//*[@id=\"cart_contents_container\"]/div/div[2]/a[2]")).click();
	}
	
	

}
