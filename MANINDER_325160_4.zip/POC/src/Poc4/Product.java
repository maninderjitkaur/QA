package Poc4;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class Product {
	WebDriver dr;
	public  String name;
	public float price;
	public String xpath;
	
	ArrayList<Product> ap=new ArrayList<Product>();
	
	
	
	public Product(WebDriver dr){
		this.dr=dr;
		PageFactory.initElements(dr, this);
	}
	
	public  void add() 
	{
		Product p = new Product("Sauce Labs Backpack",29.99f,"//*[@id=\"inventory_container\"]/div/div[1]/div[3]/button");
	
		ap.add(p);

		Product p1=new Product("Sauce Labs Bike Light",9.99f,"//*[@id=\"inventory_container\"]/div/div[2]/div[3]/button");
		Product p2=new Product("Sauce Labs Bolt T-Shirt",15.99f,"//*[@id=\"inventory_container\"]/div/div[3]/div[3]/button");

		Product p3=new Product("Sauce Labs Fleece Jacket",49.99f,"//*[@id=\"inventory_container\"]/div/div[4]/div[3]/button");
		Product p4=new Product("Sauce Labs Onesie",7.99f,"//*[@id=\"inventory_container\"]/div/div[5]/div[3]/button");
		Product p5=new Product("Test.allTheThings() T-Shirt (Red)",15.99f,"//*[@id=\"inventory_container\"]/div/div[6]/div[3]/button");
		ap.add(p1);
		ap.add(p2);
		ap.add(p3);
		ap.add(p4);
		ap.add(p5);
		
	}
	
	public Product(String name, float price, String xp) 
	{
		// TODO Auto-generated method stub
		this.name=name;
		this.price=price;
		this.xpath=xp;
		
	}

	public void add_product(String pn) {
//		dr.manage().window().maximize();
		add();
		
//		System.out.println(ap.get(0));
		for(Product p:ap) {
//			System.out.println(p+"+"+pn);
			if((p.name).equals(pn)) {
				dr.findElement(By.xpath(p.xpath)).click();
//				dr.findElement(By.xpath("//*[@id=\"shopping_cart_container\"]/a/svg/path")).click();
				
				
			}
		}
	}
	public void click_cart() {
		dr.findElement(By.xpath("//div[@class='shopping_cart_container']")).click();
	}
	
	
	
}
