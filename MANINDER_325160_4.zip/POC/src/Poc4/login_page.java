package Poc4;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

public class login_page {
	WebDriver dr;
	public login_page(WebDriver dr){
		this.dr=dr;
		PageFactory.initElements(dr, this);
	}
	 public void login(String id,String pass) {
		 
		  dr.get("https://www.saucedemo.com/");
		  dr.findElement(By.xpath("//*[@id=\"user-name\"]")).sendKeys(id);
		  dr.findElement(By.xpath("//*[@id=\"password\"]")).sendKeys(pass);
		  dr.findElement(By.xpath("//*[@id=\"login_button_container\"]/div/form/input[3]")).click();
	  }
	

}
